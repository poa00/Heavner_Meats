from pathlib import Path
import jsons

# Define your username and password
username = "sam fisher"
password = "3213"
port = 5613
ip = "http://127.0.0.1"
base_url = f"http://127.0.0.1:{port}"
