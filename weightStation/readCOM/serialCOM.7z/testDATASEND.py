import serial
import time

def send_data_to_com_port(ser, data):
    try:
        # Open the serial port
        
        # Wait for a moment to allow the serial port to initialize
        time.sleep(2)
        
        # Send data to the serial port
        ser.write(data.encode('utf-8'))
        
        # Close the serial port
        ser.close()
        
        print(f"Data sent successfully to {com_port} at {baud_rate} baud rate with {data_bits} data bits.")
    except Exception as e:
        print(f"Error: {e}")
        time.sleep(2)


# Example usage
if __name__ == "__main__":
    # Replace 'COMx' with your specific COM port (e.g., 'COM1' on Windows or '/dev/ttyUSB0' on Linux)
    com_port = 'Scale 1'
    baud_rate = 9600  # Replace with your specific baud rate
    data_bits = 8     # Replace with the desired number of data bits
    data_to_send = "Hello, COM port!"
    ser = serial.Serial(com_port, baud_rate, bytesize=data_bits, timeout=1)
    
    while True:
        send_data_to_com_port(ser, data_to_send)
